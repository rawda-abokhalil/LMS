const db = require('../db');

class system{

}